package com.israel.coupons.idao;

import com.israel.coupons.beans.Customer;

public interface ICustomerDao {

	public long createCustomer(Customer customer);

	public void updateCustomer(Customer customer);

	public Customer getCustomer(long userId);

	public void deleteCustomer(long userId);

	public boolean IsCustomerExistsByName(String customerName);
}


