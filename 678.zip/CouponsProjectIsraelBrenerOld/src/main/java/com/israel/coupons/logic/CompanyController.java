package com.israel.coupons.logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.israel.coupons.beans.Company;
import com.israel.coupons.dao.CompanyDao;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;
import com.israel.coupons.utils.JdbcUtils;

@Controller
public class CompanyController {

	@Autowired
	private CompanyDao companyDao;

//		public CompanyController() {
//			this.companyDao = new CompanyDao();
//		}

	public long createCompany(Company company) throws ApplicationException {

		if  (company.getName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null name");
		}
		if  (company.getName() .isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty name");
		}
		if  (company.getName()  != (String)company.getName() ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Name must be a String");
		}
		// check this validation with class CompanyApi
		if (isCompanyExistsByName(company.getName())) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company already exists sby name");
		}
		return this.companyDao.createCompany(company);	
	}

	public void updateCompany(Company company) throws ApplicationException {

		if  (company.getName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null name");
		}
		if  (company.getName() .isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty name");
		}
		if  (company.getName() != (String)company.getName() ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Name must be a String");
		}
		if (isCompanyExistsByName(company.getName())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Company already exists by name");
		}
		if (company.getCompanyId() !=(long)company.getCompanyId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (company.getCompanyId() <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		if (!isCompanyExistsById(company.getCompanyId())) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company does not exist by Id");
		}
		this.companyDao.updateCompany(company);
	}

	public Company getCompanyById(long companyId) throws ApplicationException {

		if (companyId !=(long)companyId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (companyId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		if (!isCompanyExistsById(companyId)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company does not exist by Id");
		}
		return this.companyDao.getCompanyById(companyId);
	}

	public List<Company> getAllCompanies() throws ApplicationException {
		validateGetAllCompanies();
		return companyDao.getAllCompanies();
	}
	
	public void deleteCompany(long companyId) throws ApplicationException {

		if (companyId !=(long)companyId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (companyId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		if (!isCompanyExistsById(companyId)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company does not exists by Id ");
		}
		this.companyDao.deleteCompany(companyId);
	}

	public boolean isCompanyExistsById(long companyId) throws ApplicationException {

		if (companyId !=(long)companyId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (companyId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		return this.companyDao.isCompanyExistsById(companyId);
	}

	public boolean isCompanyExistsByName(String name) throws ApplicationException {
		if  (name == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null name");
		}
		if  (name.isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty name");
		}
		if  (name != (String)name) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Name must be a String");
		}
		return companyDao.isCompanyExistsByName(name);
	}

	private void validateGetAllCompanies() throws ApplicationException {
		List<Company> companies = companyDao.getAllCompanies();
		if (companies.isEmpty()) {
			throw new ApplicationException(ErrorType.THE_LIST_IS_EMPTY," The list of companies is empty");
		}
	}
	
}
