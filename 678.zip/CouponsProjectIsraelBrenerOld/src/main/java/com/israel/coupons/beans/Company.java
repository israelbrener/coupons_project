package com.israel.coupons.beans;

public class Company {
	private long companyId; 
	private String name;
	private String address;

	// Default constructor (means NO parameters)
	public Company(){
	}
	// Full constructor 
	public Company(long companyId, String name, String address) {
		this.companyId = companyId;
		this.name = name;
		this.address = address;
	}
	// Full constructor without the 1st id field
	public Company(String name, String address) {
		this.name = name;
		this.address = address;
	}
	//getters & setters
	public long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", name=" + name + ", address=" + address + "]";
	}
	
}
