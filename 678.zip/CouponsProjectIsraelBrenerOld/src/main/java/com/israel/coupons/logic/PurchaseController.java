package com.israel.coupons.logic;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.israel.coupons.beans.Purchase;
import com.israel.coupons.dao.PurchaseDao;
import com.israel.coupons.dao.CouponDao;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;

@Controller
public class PurchaseController {


	@Autowired
	private PurchaseDao purchaseDao;
	@Autowired
	private UserController userController;
	@Autowired
	private CouponDao couponDao;

	public PurchaseController() {
		this.purchaseDao = new PurchaseDao();
		this.userController = new UserController();
		this.couponDao = new CouponDao();
	}

	public long createPurchase(Purchase purchase) throws ApplicationException {

		if  (purchase.getUserId() != (long)purchase.getUserId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}	
		if  (purchase.getUserId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}	
		if (!userController.isUserExistsById(purchase.getUserId())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User Id does not exist , pls. change it");
		}	
		if  (purchase.getCouponId() != (long)purchase.getCouponId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer number");
		}	
		if  (purchase.getCouponId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}
		if (!purchaseDao.isPurchaseExistsByCouponId(purchase.getCouponId())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Coupon Id does not exist in purchases");
		}	
		if  (purchase.getAmountPurchased() != (int)purchase.getAmountPurchased()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Amount Purchased must be an integer number");
		}	
		if  (purchase.getAmountPurchased() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Amount Purchased must be positive");
		}
		return  this.purchaseDao.createPurchase(purchase);
	}

	public Purchase getPurchaseById(long purchaseId) throws ApplicationException {

		if  (purchaseId != (long)purchaseId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be an integer number");
		}	
		if  (purchaseId <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}		
		if  (!purchaseDao.isPurchaseExistsById(purchaseId)) {
			throw new ApplicationException(ErrorType.INVALID_ID, "Purchase Id does not exist, aborting");
		}	
		return  this.purchaseDao.getPurchaseById(purchaseId);		
	}

	public List<Purchase>getAllPurchases() throws ApplicationException  {

		validateGetAllPurchases();
		return this.purchaseDao.getAllPurchases();
	}

	public List<Purchase> getAllPurchasesByCouponId(long couponId) throws ApplicationException {
		validateCouponIdExists(couponId);
		return purchaseDao.PurchasesByCouponId(couponId);
	}

	public void updatePurchase(Purchase purchase) throws ApplicationException {

		if  (purchase.getUserId() != (long)purchase.getUserId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}	
		if  (purchase.getUserId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if (!purchaseDao.isPurchaseExistsByUserId(purchase.getUserId())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User Id does not exist in purchases");
		}	
		if  (purchase.getCouponId() != (long)purchase.getCouponId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer number");
		}	
		if  (purchase.getCouponId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}
		if (!purchaseDao.isPurchaseExistsByCouponId(purchase.getCouponId())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Coupon Id does not exist in purchases");
		}	
		if  (purchase.getAmountPurchased() != (int)purchase.getAmountPurchased()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Amount Purchased must be an integer number");
		}	
		if  (purchase.getAmountPurchased() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Amount Purchased must be positive");
		}
		if  (purchase.getPurchaseId() != (long)purchase.getPurchaseId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be an integer number");
		}	
		if  (purchase.getPurchaseId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}
		if (!purchaseDao.isPurchaseExistsById(purchase.getPurchaseId())) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id does not exist, aborting");
		}	
		this.purchaseDao.updatePurchase(purchase);
	}

	public void deletePurchase(long purchaseId) throws ApplicationException {		

		if (purchaseId !=(long)purchaseId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be an integer number");
		}
		if (purchaseId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}
		if (!purchaseDao.isPurchaseExistsById(purchaseId)) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Purchase Id does not exist, aborting");
		}	
		this.purchaseDao.deletePurchase(purchaseId);
	}

	public void removeOldCouponPurchases(java.sql.Date todayDate) throws ApplicationException {

		if (todayDate==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null date");
		}
		if  (todayDate.equals(null)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty date");
		}			
		this.purchaseDao.removeOldCouponPurchases(todayDate);
	}

	public Long[] checkOldCouponPurchases(java.sql.Date todayDate) throws ApplicationException{

		if (todayDate==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null date");
		}
		if  (todayDate.equals(null)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty date");
		}	
		return this.purchaseDao.checkOldCouponPurchases(todayDate);
	}	

	public boolean isPurchaseExistsById(long purchaseId) throws ApplicationException {

		if (purchaseId !=(long)purchaseId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be an integer numbe");
		}
		if (purchaseId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Purchase Id must be positive");
		}
		return this.purchaseDao.isPurchaseExistsById(purchaseId);
	}

	public boolean isPurchaseExistsByUserId(long userId) throws ApplicationException {

		if (userId !=(long)userId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}
		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		return this.purchaseDao.isPurchaseExistsByUserId(userId);
	}

	public boolean isPurchaseExistsByCouponId(long couponId) throws ApplicationException {

		if (couponId !=(long)couponId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer number");
		}
		if (couponId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be positive");
		}
		return this.purchaseDao.isPurchaseExistsByCouponId(couponId);
	}

	private void validateGetAllPurchases() throws ApplicationException {
		List<Purchase> purchases = purchaseDao.getAllPurchases();
		if (purchases.isEmpty()) {
			throw new ApplicationException(ErrorType.THE_LIST_IS_EMPTY,"The list of users is empty");			
		}
	}

	private void validateCouponIdExists(long couponId) throws ApplicationException {
		if(!couponDao.isCouponExistsById(couponId)) {
			throw new ApplicationException(ErrorType.INVALID_ID, "The ID you've entered is invalid");
		}
	}

}	