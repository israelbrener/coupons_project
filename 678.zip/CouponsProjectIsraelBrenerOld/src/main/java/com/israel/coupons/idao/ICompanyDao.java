package com.israel.coupons.idao;

import com.israel.coupons.beans.Company;

public interface ICompanyDao {

	public long createCompany(Company company);

	public void updateCompany(Company company);

	public Company getCompany(long companyId);

	public void deleteCompany(long companyId);

	public boolean isCompanyExistsByName(String companyName);
}
