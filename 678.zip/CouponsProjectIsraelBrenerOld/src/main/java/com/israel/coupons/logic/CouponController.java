package com.israel.coupons.logic;

import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.israel.coupons.beans.Coupon;
import com.israel.coupons.beans.User;
import com.israel.coupons.dao.CouponDao;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;

@Controller
public class CouponController {

	@Autowired
	private CouponDao couponDao;

//	public CouponController() {
//		this.couponDao = new CouponDao();
//	}

	public long createCoupon(Coupon coupon) throws ApplicationException {

		if (coupon.getDescription()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null description");
		}
		if  (coupon.getDescription().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty description");
		}
		if (coupon.getImage()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null image");
		}
		if  (coupon.getImage().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty image");
		}
		if (coupon.getStartDate().equals(null)) {
			System.out.println("Null start date");
		}
		if (coupon.getEndDate().equals(null)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null end date");
		}
		if(coupon.getEndDate().before(coupon.getStartDate())) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR,"End date is before start date");
		}
		if (coupon.getPrice()==0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "price is zero, pls. change it");
		}
		if (coupon.getAmount()==0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "amount is zero, pls. change it");
		}
		if (coupon.getTitle()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null title");
		}
		if  (coupon.getTitle().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty title");
		}
		 return this.couponDao.createCoupon(coupon);
	}

	public void updateCoupon(Coupon coupon) throws ApplicationException{
		
		if (coupon.getCouponId() !=(long)coupon.getCouponId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer numbe");
		}
		if (coupon.getCouponId() <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be positive");
		}
		if(!isCouponExistsById (coupon.getCouponId())) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon does not exists by Id");
		}
		if (coupon.getCompanyId() !=(long)coupon.getCompanyId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (coupon.getCompanyId() <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		this.couponDao.updateCoupon(coupon);
	}

	public Coupon getCouponById(long couponId) throws ApplicationException{

		if (couponId !=(long)couponId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer numbe");
		}
		if (couponId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be positive");
		}
		if(!isCouponExistsById(couponId)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon does not exists by Id");
		}
		return this.couponDao.getCouponById(couponId);
	}

	public List<Coupon> getAllCoupons() throws ApplicationException  {

		validateGetAllCoupons();
		return  couponDao.getAllCoupons();
	}
	
	public void deleteCoupon(long couponId) throws ApplicationException{
	
		if (couponId !=(long)couponId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer numbe");
		}
		if (couponId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be positive");
		}
		if(!isCouponExistsById (couponId)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon does not exists by Id");
		}
		 this.couponDao.deleteCoupon(couponId);
	}
	
	public void removeOldCoupons(java.sql.Date todayDate) throws ApplicationException {

		if (todayDate==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null date");
		}
		if  (todayDate.equals(null)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty date");
		}		
		 this.couponDao.removeOldCoupons(todayDate);
	}
	
	public Long[] checkOldCoupons(java.sql.Date todayDate) throws ApplicationException{
		
		if (todayDate==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "null date");
		}
		if  (todayDate.equals(null)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "empty date");
		}	
		 return this.couponDao.checkOldCoupons(todayDate);
	}
	
	public boolean isCouponExistsById(long couponId) throws ApplicationException {

		if (couponId !=(long)couponId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be an integer numbe");
		}
		if (couponId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Coupon Id must be positive");
		}
		return this.couponDao.isCouponExistsById(couponId);
	}

	public boolean isCouponExistsByCompanyId(long companyId) throws ApplicationException {
	
		if (companyId !=(long)companyId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be an integer numbe");
		}
		if (companyId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Company Id must be positive");
		}
		return this.couponDao.isCouponExistsByCompanyId(companyId);
	}
	
	private void validateGetAllCoupons() throws ApplicationException {
		List<Coupon> coupons = couponDao.getAllCoupons();
		if (coupons.isEmpty()) {
			throw new ApplicationException(ErrorType.THE_LIST_IS_EMPTY,"The list of coupons is empty");			
		}
	}
}
