package com.israel.coupons.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.israel.coupons.enums.UserType;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;
import com.israel.coupons.beans.User;
import com.israel.coupons.utils.JdbcUtils;

@Repository
public class UserDao {


	public UserDao() {
	}

	public long createUser(User user) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//UserID is defined as a primary key and auto incremented
			String sqlStatement="INSERT INTO users (USER_NAME, EMAIL, PASSWORD, TYPE, COMPANY_ID ) VALUES(?,?,?,?,?)";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getEmail());
			preparedStatement.setString(3,user.getPassword());
			preparedStatement.setString(4,user.getType().name());
			preparedStatement.setLong(5,user.getCompanyId());

			//Executing the update
			preparedStatement.executeUpdate();

			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(!resultSet.next()){
				throw new ApplicationException(ErrorType.GENERAL_ERROR,"Failed to create user id");
			}
			return resultSet.getLong(1);
		} catch (SQLException e) {
			e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Create user has failed (method createUser)"); 
			//			throw new Exception("Failed to create user " + user.toString()));
		} 
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public User getUserById(long userId) throws ApplicationException {
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		User user;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM users WHERE USER_ID =?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				//				return null ;		
				throw new ApplicationException(ErrorType.GENERAL_ERROR, "Error in getUser(), id = " + userId);
			}
			user=extractUserFromResultSet(result);

		} catch (SQLException e) {
			//			throw new Exception("Error in getUser(), id = " + userId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get user (method getUserByUserID) has failed");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return user;
	}

	public  List<User> getAllUsers() throws ApplicationException{
		List<User> users =  new ArrayList<User>();
		//Turn on the connections
				Connection connection=null;
				PreparedStatement preparedStatement=null;
				ResultSet result=null;

				try {
					//Establish a connection from the connection manager
					connection=JdbcUtils.getConnection();

					//Creating the SQL query
					String sqlStatement="SELECT * FROM users";

					//Combining between the syntax and our connection
					preparedStatement = connection.prepareStatement(sqlStatement);

					//Executing the query and saving the DB response in the resultSet.
					result=preparedStatement.executeQuery();
					
					while (result.next()) {
						users.add(extractUserFromResultSet(result));
					}

				} catch (SQLException e) {
					//			throw new Exception("Error in getUser(), id = " + userId, e);
					//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
					throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
							+" Get all users (method getAllUsers) has failed");
				}
				finally {
					//Closing the resources
					JdbcUtils.closeResources(connection, preparedStatement, result);	
				}
				return users;
	}
	
	public void updateUser(User user) throws ApplicationException{

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection = JdbcUtils.getConnection();

			//Creating the SQL query
			//Id is defined as a primary key and auto incremented
			String sqlStatement="UPDATE users SET USER_NAME = ?, EMAIL = ?, PASSWORD = ?, TYPE = ?, COMPANY_ID = ? WHERE USER_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, user.getPassword());
			preparedStatement.setString(4, user.getType().name());
			preparedStatement.setLong(5, user.getCompanyId());
			preparedStatement.setLong(6, user.getUserId());

			//Executing the update
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			//e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Update user failed (method updateUser)" +user.toString());
			//			throw new Exception("Failed to update user " + user.toString(), e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void deleteUser(long userId) throws ApplicationException{

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//UserID is defined as a primary key and auto incremented
			String sqlStatement="DELETE FROM users where USER_ID=?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the update
			preparedStatement.executeUpdate();
			//			throw new Exception("Failed to remove user " + userId, e);
		} catch (Exception e) {
			//					e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Delete user failed method(deleteUser) +userId: "+ userId);
			//			throw new Exception("Failed to remove user " + userId, e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	private User extractUserFromResultSet(ResultSet result) throws SQLException {
		User user=new User();
		user.setUserId(result.getLong("USER_ID"));
		user.setUserName(result.getString("USER_NAME"));
		user.setEmail(result.getString("EMAIL"));
		user.setPassword(result.getString("PASSWORD"));
		user.setType(UserType.valueOf(result.getString("TYPE")));
		user.setCompanyId(result.getLong("COMPANY_ID"));
		return user;
	}

	public boolean isUserExistsByName(String userName) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM users WHERE USER_NAME = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1, userName);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if user exists by username (method isUserExistsByName)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

	public boolean isUserExistsById(long userId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM users WHERE USER_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if user exists by user Id (method isUserExistsByUserId)" );
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}
	
	public UserType  userClientTypeLogin(String userName, String password) throws ApplicationException {
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM users WHERE USER_NAME = ? && PASSWORD = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			// Login had failed (!!!!!!!!!!!!!!!)
			if (!result.next()) {
				throw new ApplicationException(ErrorType.LOGIN_FAILED, "Failed login");
			}

			UserType clientType = UserType.valueOf(result.getString("type"));
			return clientType;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get client type has failed  (method login)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
	}

}
