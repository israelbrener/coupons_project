package com.israel.coupons.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.israel.coupons.beans.Company;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.logic.CompanyController;

@RestController
@RequestMapping("/company")
public class CompanyApi {

	//@RequestMapping(method="get", url="/login")

	@Autowired
	private CompanyController companyController;

	//method=POST   url=http://localhost:8080/company
	@PostMapping
	public void createCompany(@RequestBody Company company) throws ApplicationException {
		long id = this.companyController.createCompany(company);
		System.out.println("The id of the created company is: " + id);
	}

	//method=GET   url=http://localhost:8080/company/444
		@GetMapping("/{companyId}")
		public Company getCompany(@PathVariable("companyId") long id) throws ApplicationException {
			System.out.println("company id is: " + id);
			return this.companyController.getCompanyById(id);
		}
		
		//method=GET   url=http://localhost:8080/company
		@GetMapping
		public List<Company> getAllCompanies() throws ApplicationException {
			System.out.println("we have to get all conpanies list on webpage");
			return this.companyController.getAllCompanies();
		}

		//method=PUT   url=http://localhost:8080/company
		@PutMapping
		public void updateCompany(@RequestBody Company company) throws ApplicationException {
			this.companyController.updateCompany(company);
			System.out.println("updated company is: " + company);
		}

		//Delete company from companies (COMPANY_ID is a FK in users & coupons)
		//method=DELETE   url=http://localhost:8080/company/444
		@DeleteMapping("/{companyId}")
		public void deleteCompany(@PathVariable("companyId") long id) throws ApplicationException {
			this.companyController.deleteCompany(id);
			System.out.println("Delete company id: " + id);
		}
		
}
