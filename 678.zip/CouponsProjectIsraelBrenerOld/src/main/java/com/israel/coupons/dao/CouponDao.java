package com.israel.coupons.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

//import java.sql.Date;
import com.israel.coupons.utils.DateUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.israel.coupons.beans.Coupon;
import com.israel.coupons.beans.User;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.JdbcUtils;

@Repository
public class CouponDao {

	public CouponDao() {
	}

	public long createCoupon(Coupon coupon) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CompanyID is defined as a primary key and auto incremented
			String sqlStatement="INSERT INTO coupons (COMPANY_ID, CATEGORY_ID, TITLE, DESCRIPTION, START_DATE, END_DATE, AMOUNT, PRICE, IMAGE) VALUES(?,?,?,?,?,?,?,?,?)";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1,coupon.getCompanyId());
			preparedStatement.setLong(2,coupon.getCategoryId());
			preparedStatement.setString(3,coupon.getTitle());
			preparedStatement.setString(4,coupon.getDescription());
			preparedStatement.setDate(5,  coupon.getStartDate());
			preparedStatement.setDate(6, coupon.getEndDate());
			preparedStatement.setInt(7,coupon.getAmount());
			preparedStatement.setFloat(8,coupon.getPrice());
			preparedStatement.setString(9,coupon.getImage());


			//Executing the update
			preparedStatement.executeUpdate();

			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(!resultSet.next()){
				throw new ApplicationException(ErrorType.GENERAL_ERROR,"Invalid coupon key during creation");
			}
			return resultSet.getLong(1);


		} catch (Exception e) {
			//			e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Create coupon failed (method createCoupon)");
			//			throw new Exception("Failed to create coupon " + coupon.toString(), e);
		} 
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public Coupon getCouponById(long couponId) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		Coupon coupon;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//String sqlStatement="SELECT * FROM coupons WHERE COUPON_ID =?";
			String sqlStatement="SELECT COUPON_ID, COMPANY_ID, CATEGORY_ID, TITLE, DESCRIPTION, START_DATE, END_DATE, AMOUNT, PRICE, IMAGE FROM coupons WHERE COUPON_ID =?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, couponId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return null;
			}
			coupon=extractCouponFromResultSet(result);

		} catch (SQLException e) {
			//			throw new Exception("Error in getCompany(), id = " + couponId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get coupon by id has failed (method getCouponById)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return coupon;

	}

	public List<Coupon> getAllCoupons() throws ApplicationException{
		List<Coupon> coupons =  new ArrayList<Coupon>();
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM coupons";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			while (result.next()) {
				coupons.add(extractCouponFromResultSet(result));
			}

		} catch (SQLException e) {
			//			throw new Exception("Error in getcoupon(), id = " + userId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get all coupons (method getAllCoupons) has failed");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return coupons;
	}

	public void updateCoupon(Coupon coupon) throws ApplicationException {
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection = JdbcUtils.getConnection();

			//Creating the SQL query
			//Id is defined as a primary key and auto incremented
			String sqlStatement="UPDATE coupons SET COMPANY_ID  = ?, CATEGORY_ID = ?, TITLE = ?, DESCRIPTION = ?, START_DATE = ?, END_DATE = ?, AMOUNT = ?, PRICE = ?, IMAGE = ? WHERE COUPON_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1,coupon.getCompanyId());
			preparedStatement.setLong(2,coupon.getCategoryId());
			preparedStatement.setString(3,coupon.getTitle());
			preparedStatement.setString(4,coupon.getDescription());
			preparedStatement.setDate(5, coupon.getStartDate());
			preparedStatement.setDate(6,coupon.getEndDate());
			preparedStatement.setInt(7,coupon.getAmount());
			preparedStatement.setFloat(8,coupon.getPrice());
			preparedStatement.setString(9, coupon.getImage());
			preparedStatement.setLong(10, coupon.getCouponId());

			//Executing the update
			preparedStatement.executeUpdate();

		} catch (Exception e) {
			//e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" update coupon failed (method updateCoupon)");
			//			throw new Exception("Failed to update coupon " + coupon.toString(), e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void deleteCoupon(long couponId) throws ApplicationException{

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CouponId is defined as a primary key and auto incremented
			String sqlStatement="DELETE FROM coupons where COUPON_ID=?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, couponId);

			//Executing the update
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			//			e.printStackTrace();
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" deletr coupon failed (method deleteCoupon)");
			//			throw new Exception("Failed to remove coupon " + couponId, e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void removeOldCoupons(java.sql.Date todayDate) throws ApplicationException {

		//		long now = Calendar.getInstance().getTimeInMillis();
		//		Date todayDate1 = new Date(now);

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CouponId is defined as a primary key and auto incremented
			String sqlStatement="delete from coupons where END_DATE < current_date();";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			//			preparedStatement.setLong(1, couponId);

			//Executing the update
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			//					e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			//					throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
			//							+" Create company failed");
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" remove old coupons failed (method removeOldCoupons)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public Long[] checkOldCoupons(java.sql.Date todayDate) throws ApplicationException{

		//		long now = Calendar.getInstance().getTimeInMillis();
		//		Date todayDate1 = new Date(now);

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		Long[] arrResultCouponId;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CompanyID is defined as a primary key and auto incremented
			//			String sqlStatement="SELECT COUPON_ID, COMPANY_ID, CATEGORY_ID, TITLE, DESCRIPTION, START_DATE, END_DATE, AMOUNT, PRICE, IMAGE FROM coupons where END_DATE < current_date();";
			String sqlStatement="SELECT COUPON_ID FROM coupons where END_DATE < current_date();";
			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			//			preparedStatement.setLong(1, couponId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return null;
			}
			arrResultCouponId = extractCouponIdFromResultSet(result);

		} catch (SQLException e) {
			//			throw new Exception("Error in getCompany(), id = " + couponId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+"check old  coupons has failed (method checkOldCoupons)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return arrResultCouponId;
	}

	private Coupon extractCouponFromResultSet(ResultSet result) throws SQLException{
		Coupon coupon=new Coupon();
		coupon.setCouponId(result.getLong("COUPON_ID"));
		coupon.setCompanyId(result.getLong("COMPANY_ID"));
		coupon.setCategoryId(result.getLong("CATEGORY_ID"));
		coupon.setTitle(result.getString("TITLE"));
		coupon.setDescription(result.getString("DESCRIPTION"));
		coupon.setStartDate(result.getDate("START_DATE"));
		coupon.setEndDate(result.getDate("END_DATE"));
		coupon.setAmount(result.getInt("AMOUNT"));
		coupon.setPrice(result.getFloat("PRICE"));
		coupon.setImage(result.getString("IMAGE"));
		return coupon;
	}

	private Long[] extractCouponIdFromResultSet(ResultSet result) throws SQLException{

		int size =0;
		if (result != null) 
		{
			result.last();    // moves cursor to the last row
			size = result.getRow(); // get row id 
		}		
		System.out.println("The size of the result  is :" +size +" rows"); //for debugging

		Long[] arrResultCouponId = new Long[size];
		Coupon coupon=new Coupon();
		for (int i =0; i < size; i++){
			coupon.setCouponId(result.getLong("COUPON_ID"));
			arrResultCouponId[i] = coupon.getCouponId();
			result.absolute(i+1);
		}

		return arrResultCouponId;
	}

	public boolean isCouponExistsById(long couponId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM coupons WHERE COUPON_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, couponId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if coupon exists by coupon Id (method isCouponExistsById)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

	public boolean isCouponExistsByCompanyId(long companyId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM coupons WHERE COMPANY_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, companyId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if coupon exists by company Id (method isCouponExistsByCompanyId)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

}
