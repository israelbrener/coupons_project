package com.israel.coupons.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.israel.coupons.beans.Coupon;
import com.israel.coupons.beans.User;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.logic.CouponController;

@RestController
@RequestMapping("/coupon")
public class CouponApi {

	//@RequestMapping(method="get", url="/login")

	@Autowired
	private CouponController couponController;

	//method=POST   url=http://localhost:8080/coupon
	@PostMapping
	public void createCoupon(@RequestBody Coupon coupon)  throws ApplicationException {
		long id = this.couponController.createCoupon(coupon);
		System.out.println("The id of the created coupon is: " + id);
	}

	//method=GET   url=http://localhost:8080/coupon/444
	@GetMapping("/{couponId}")
	public Coupon getCoupon(@PathVariable("couponId") long id) throws ApplicationException {
		System.out.println("coupon id is: " + id);
		return this.couponController.getCouponById(id);
	}

	//method=GET   url=http://localhost:8080/coupon
	@GetMapping
	public List<Coupon> getAllCoupons() throws ApplicationException {
		System.out.println("we have to get all coupons list on webpage");
		return this.couponController.getAllCoupons();
	}

	//method=PUT   url=http://localhost:8080/coupon
	@PutMapping
	public void updateCoupon(@RequestBody Coupon coupon) throws ApplicationException {
		this.couponController.updateCoupon(coupon);
		System.out.println("updated coupon is: " + coupon);
	}
	
		//Delete coupon from coupons (COUPON_ID is a FK in purchases)
	//method=DELETE   url=http://localhost:8080/coupon/444
	@DeleteMapping("/{couponId}")
	public void deleteCoupon(@PathVariable("couponId") long id) throws ApplicationException {
		this.couponController.deleteCoupon(id);
		System.out.println("Delete coupon id: " + id);
	}
}
