package com.israel.coupons.idao;

import com.israel.coupons.beans.User;

public interface IUserDao {

	public long createUser(User user);

	public void updateUser(User user);

	public User getUser(long userId);

	public void deleteUser(long userId);

	public boolean isUserExistsByName(String userName);
}












