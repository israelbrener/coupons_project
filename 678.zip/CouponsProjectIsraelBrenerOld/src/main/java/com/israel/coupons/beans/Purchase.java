package com.israel.coupons.beans;

public class Purchase {
	private long purchaseId; 
	private long userId;
	private long couponId;
	private int amountPurchased;

	// Default constructor (means NO parameters)
	public Purchase() {
	}
	// Full constructor
	public Purchase(long purchaseId, long userId, long couponId, int amountPurchased) {
		this.purchaseId = purchaseId;
		this.userId = userId;
		this.couponId = couponId;
		this.amountPurchased = amountPurchased;
	}
	//  Full constructor without the 1st id field
	public Purchase(long userId, long couponId, int amountPurchased) {
		this.userId = userId;
		this.couponId = couponId;
		this.amountPurchased = amountPurchased;
	}
	//getters & setters
	public long getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(long purchaseId) {
		this.purchaseId = purchaseId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getCouponId() {
		return couponId;
	}
	public void setCouponId(long couponId) {
		this.couponId = couponId;
	}
	public int getAmountPurchased() {
		return amountPurchased;
	}
	public void setAmountPurchased(int amountPurchased) {
		this.amountPurchased = amountPurchased;
	}
	
	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", userId=" + userId + ", couponId=" + couponId
				+ ", amountPurchased=" + amountPurchased + "]";
	}
}
