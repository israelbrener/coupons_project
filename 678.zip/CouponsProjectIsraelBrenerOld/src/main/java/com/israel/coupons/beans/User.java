package com.israel.coupons.beans;

import com.israel.coupons.enums.UserType;

public class User {
	private long userId;
	private String userName;
	private String email;
	private String password;
	private UserType  type;
	private Long companyId; // is nullable

	// Default constructor (means NO parameters)
	public User() {
	}

	// Full constructor
	public User(long userId, String userName, String email, String password, UserType type, Long companyId) {
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.type = type;
		this.companyId = companyId;
	}

	// Full constructor without the 1st id field
	public User(String userName, String email, String password, UserType type, Long companyId) {
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.type = type;
		this.companyId = companyId;
	}

	// getters & setters
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserType getType() {
		return type;
	}

	public void setType(UserType type) {
		this.type = type;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", email=" + email + ", password=" + password
				+ ", type=" + type + ", companyId=" + companyId + "]";
	}
}
