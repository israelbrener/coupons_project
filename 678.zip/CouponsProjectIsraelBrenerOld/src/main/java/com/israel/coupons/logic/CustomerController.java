package com.israel.coupons.logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.israel.coupons.beans.Customer;
import com.israel.coupons.beans.User;
import com.israel.coupons.dao.CustomerDao;
import com.israel.coupons.dao.UserDao;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;

@Controller
public class CustomerController {

	@Autowired
	private CustomerDao customerDao;

//	public CustomerController() {
//		this.customerDao = new CustomerDao();
//	}

	public long createCustomer(Customer customer, long userId) throws ApplicationException{
		if (isCustomerExistsByUserId(userId)) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Customer already exists by user Id.");
		}
		if (customer.getFirstName()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null firstName");
		}
		if  (customer.getFirstName().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty firstName");
		}
		
		if (customer.getLastName()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null lastName");
		}

		if  (customer.getLastName().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty lastName");
		}
		 return this.customerDao.createCustomer(customer,  userId);
	}

	public Customer getCustomerByCustomerID(long userId) throws ApplicationException {

		if (userId !=(long)userId) {
			System.out.println("User Id must be an integer number");
		}
		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if(! isCustomerExistsByUserId(userId) )  {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id does not exist  in customers");
		}	
		return this.customerDao.getCustomerByCustomerID(userId);		
	}

	public List<Customer>getAllCustomers() throws ApplicationException  {

		validateGetAllCustomers();
		return this.customerDao.getAllCustomers();
	}

	
	public void updateCustomer(Customer customer, long userId) throws ApplicationException {

		if (userId !=(long)userId) {
			System.out.println("User Id must be an integer number");
		}
		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if(! isCustomerExistsByUserId(userId) )  {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id does not exist  in customers");
		}	
		if  (customer.getFirstName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null firstName");
		}
		if  (customer.getFirstName() .isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty firstName");
		}
		if  (customer.getFirstName()  != (String)customer.getFirstName() ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "firstName must be a String");
		}
		if  (customer.getLastName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null lastName");
		}
		if  (customer.getLastName() .isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty lastName");
		}
		if  (customer.getLastName()  != (String)customer.getLastName() ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "lastName must be a String");
		}
		this.customerDao.updateCustomer(customer, userId);
	}

	public void deleteCustomer(long userId) throws ApplicationException {

		if (userId !=(long)userId) {
			System.out.println("Purchase Id must be an integer number");
		}
		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "purchase Id must be positive");
		}
		if (!customerDao.isCustomerExistsByUserId(userId)) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Purchase Id does not exist, aborting");
		}	

		this.customerDao.deleteCustomer(userId);

	}

	public boolean isCustomerExistsByUserId(long userId) throws ApplicationException {

		if (userId !=(long)userId) {
			System.out.println("User Id must be an integer number");
		}
		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		return this. customerDao.isCustomerExistsByUserId(userId);
	}

	public boolean isCustomerExistsByFirstName(String firstName) throws ApplicationException {

		if  (firstName == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null firstName");
		}
		if  (firstName.isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty firstName");
		}
		if  (firstName != (String)firstName) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "firstName must be a String");
		}
		return this. customerDao.isCustomerExistsByFirstName(firstName);
	}

	private void validateGetAllCustomers() throws ApplicationException {
		List<Customer> customers = customerDao.getAllCustomers();
		if (customers.isEmpty()) {
			throw new ApplicationException(ErrorType.THE_LIST_IS_EMPTY,"The list of customers is empty");			
		}
	}
}
