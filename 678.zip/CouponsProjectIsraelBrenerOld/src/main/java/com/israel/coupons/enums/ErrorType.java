package com.israel.coupons.enums;

public enum ErrorType {
GENERAL_ERROR(600, "General error"),
NAME_IS_ALREADY_EXISTS(601, "The name you chose is already exist. Please pick another name"),
INVALID_ID(602, "The ID you've entered is invalid"),
INVALID_AMOUNT(603,"The amount you've entered is invalid"),
INVALID_PRICE(604,"The price you've entered is invalid"),
INVALID_EMAIL(605,"The email you've entered is invalid. Please try again."),
INVALID_PASSWORD(606,"The password you've entered is invalid. Please try again."),
INVALID_DATES(607,"The dates you've entered is invalid. Please try again."),
FIELD_IS_IRREPLACEABLE(608, "You can't change this field."),
NAME_IS_IRREPLACEABLE(609, "You can't change your name."),
COUPON_IS_OUT_OF_ORDER(610, "Coupon is out of order"),
LOGIN_FAILED(611, "Login failed. credentials is incorrect, Please try again."),
THE_LIST_IS_EMPTY(612, "The list is empty");
	
	private int internalErrorCode;
	private String internalMessage;
	
	private ErrorType(int internalErrorCode, String internalMessage) {
		this.internalErrorCode=internalErrorCode;
		this.internalMessage=internalMessage;
	}

	public int getInternalErrorCode() {
		return internalErrorCode;
	}

	public String getInternalMessage() {
		return internalMessage;
	}
	
} 
