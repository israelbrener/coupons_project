package com.israel.coupons.beans;

public class Customer {
	private User user;
	private long userId;
	private String firstName;
	private String lastName;

	// Default constructor (means NO parameters)
	public Customer() {
	}
	// Full constructor w/o userId 
	public Customer(User user, String firstName, String lastName) {
		this.user = user;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	// Full constructor w/o User, with userId
		public Customer(long  userId, String firstName, String lastName) {
			this.userId = userId;
			this.firstName = firstName;
			this.lastName = lastName;
		}
	
	//  Full constructor without the 1st id field 
	public Customer(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	//getters & setters
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Customer [user=" + user + ", userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName
				+ "]";
	}
	
}
