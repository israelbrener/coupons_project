package com.israel.coupons.beans;

//import java.util.Date;
import java.sql.Date;
//import com.israel.coupons.utils.DateUtils;

public class Coupon {
	private long couponId;
	private long companyId;
	private long categoryId;
	private String title;
	private String description;
	private java.sql.Date startDate;
	private java.sql.Date endDate;
	private int amount;
	private float price;
	private String image;
	
	// Default constructor (means NO parameters)
	public Coupon() {
	}
	// Full constructor
	public Coupon(long couponId, long companyId, long categoryId, String title, String description, Date startDate,
			Date endDate, int amount, float price, String image) {
		this.couponId = couponId;
		this.companyId = companyId;
		this.categoryId = categoryId;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.price = price;
		this.image = image;
	}
	// Full constructor without the couponId (AI)
	public Coupon(long companyId, long categoryId, String title, String description, Date startDate, Date endDate,
			int amount, float price, String image) {
		this.companyId = companyId;
		this.categoryId = categoryId;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.price = price;
		this.image = image;
	}

	//getters & setters
	public long getCouponId() {
		return couponId;
	}
	public void setCouponId(long couponId) {
		this.couponId = couponId;
	}
	public long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}
	public long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public  java.sql.Date getStartDate() {
		return  startDate;
	}
	public void setStartDate(java.sql.Date startDate) {
		this.startDate = startDate;
	}
	public java.sql.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	@Override
	public String toString() {
		return "Coupon [couponId=" + couponId + ", companyId=" + companyId + ", categoryId=" + categoryId + ", title="
				+ title + ", description=" + description + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", amount=" + amount + ", price=" + price + ", image=" + image + "]";
	}
}



