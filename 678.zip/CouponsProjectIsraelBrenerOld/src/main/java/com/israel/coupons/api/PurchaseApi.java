package com.israel.coupons.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.israel.coupons.beans.Purchase;
import com.israel.coupons.beans.User;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.logic.PurchaseController;

@RestController
@RequestMapping("/purchase")
public class PurchaseApi {

	//@RequestMapping(method="get", url="/login")

	@Autowired
	private PurchaseController purchaseController;

	//method=POST   url=http://localhost:8080/purchase
	@PostMapping
	public void createPurchase(@RequestBody Purchase purchase)  throws ApplicationException {
		long id = this.purchaseController.createPurchase(purchase);
		System.out.println("The id of the created purchase is: " + id);
	}

	//method=GET   url=http://localhost:8080/purchase/444
	@GetMapping("/{purchaseId}")
	public Purchase getPurchase(@PathVariable("purchaseId") long id) throws ApplicationException {
		System.out.println("purchase id is: " + id);
		return this.purchaseController.getPurchaseById(id);	
	}

	//method=GET   url=http://localhost:8080/purchase
	@GetMapping
	public List<Purchase> getAllPurchases() throws ApplicationException {
		System.out.println("we have to get all purchases list on webpage");
		return this.purchaseController.getAllPurchases();
	}
	
	//method=PUT   url=http://localhost:8080/purchase
	@PutMapping
	public void updateUser(@RequestBody Purchase purchase) throws ApplicationException {
		this.purchaseController.updatePurchase(purchase);
		System.out.println("updated purchase is: " + purchase);
	}

	//Delete purchase from purchases (COMPANY_ID is a FK in users)
	//method=DELETE   url=http://localhost:8080/purchase/444
	@DeleteMapping("/{purchaseId}")
	public void deletePurchase(@PathVariable("purchaseId") long id) throws ApplicationException {
		this.purchaseController.deletePurchase(id);
		System.out.println("Delete purchase id: " + id);
	}

	// url = "/coupon/byCouponId?couponId=42
	@GetMapping("/byCouponId")
	public List<Purchase> getAllPurchasesByCouponId(@RequestParam("couponId") long couponId) throws ApplicationException {
		System.out.println("we have to get on webpage all purchases list of couponId: " + couponId);
		return this.purchaseController.getAllPurchasesByCouponId(couponId);
	}
	
	
}

