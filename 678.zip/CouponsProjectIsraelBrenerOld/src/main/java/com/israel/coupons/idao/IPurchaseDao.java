package com.israel.coupons.idao;

import com.israel.coupons.beans.Purchase;

public interface IPurchaseDao {

	public long createPurchase(Purchase purchase);

	public void updatePurchase(Purchase purchase);

	public Purchase getPurchase(long purchaseId);

	public void deletePurchase(long purchaseId);

	public boolean isPurchaseExistsByUsrerIdAndCouponID(long userId, long couponId);
}
