package com.israel.coupons.idao;

import java.sql.Date;

import com.israel.coupons.beans.Coupon;

public interface ICouponDao {

	public long createCoupon(Coupon coupon);

	public void updateCoupon(Coupon coupon);

	public Coupon getCoupon(long couponId);

	public void deleteCoupon(long couponId) ;

	public boolean isCouponExistsByTitle(String couponTitle) ;
}
