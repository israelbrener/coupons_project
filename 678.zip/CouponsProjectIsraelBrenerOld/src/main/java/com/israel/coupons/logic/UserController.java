package com.israel.coupons.logic;

import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;
import com.israel.coupons.utils.JdbcUtils;
import com.israel.coupons.enums.UserType;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.data.LoginResponseDataObject;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.israel.coupons.beans.User;
import com.israel.coupons.dao.UserDao;

@Controller
public class UserController {

	@Autowired
	private UserDao userDao;
	@Autowired
	private LoginResponseDataObject loginResponseDataObject;

//		public UserController() {
//			this.userDao = new UserDao();
//		}

	public long createUser(User user) throws ApplicationException {

		if  (user.getUserName().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty username");
		}
		if  (user.getUserName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null username");
		}
		if (userDao.isUserExistsByName(user.getUserName())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User name already exists - pls. change it");
		}
		if (user.getEmail() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null email");
		}
		if  (user.getEmail().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty email");	
		}
		if (user.getPassword()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null password");
		}
		if  (user.getPassword().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty password");
		}
		if (user.getType()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null type");
		}
		//				if  (user.getType().isEmpty()) {
		//			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty type");
		//		}
		if  (user.getCompanyId()==0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "companyId can't be zero");
		}
		return this.userDao.createUser(user);
	}

	public User getUserById(long userId) throws ApplicationException {

		if  (userId != (long)userId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}	
		if  (userId <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if (!userDao.isUserExistsById(userId)) {
			throw new ApplicationException(ErrorType.INVALID_ID, "User Id does not exist, aborting");
		}
		return  this.userDao.getUserById(userId);		
	}

	public List<User>getAllUsers() throws ApplicationException  {

		validateGetAllUsers();
		return this.userDao.getAllUsers();
	}

	public void updateUser(User user) throws ApplicationException {

		if  (user.getUserId() != (long)user.getUserId()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}	
		if  (user.getUserId() <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if (!userDao.isUserExistsById(user.getUserId())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User Id does not exist, aborting");
		}	
		if  (user.getUserName() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null username");
		}
		if  (user.getUserName().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty username");
		}
		if (userDao.isUserExistsByName(user.getUserName())) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User name already exists - pls. change it");
		}	
		if (user.getEmail() == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null email");
		}
		if  (user.getEmail().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty email");	
		}
		if (user.getPassword()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null password");
		}
		if  (user.getPassword().isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty password");
		}
		if (user.getType()==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null type");
		}
		//		if  (user.getType().isEmpty()) {
		//			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty type");
		//		}
		this.userDao.updateUser(user);
	}

	public void deleteUser(long userId) throws ApplicationException  {		

		if  (userId != (long)userId) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be an integer number");
		}	
		if  (userId <= 0 ) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "User Id must be positive");
		}
		if (!userDao.isUserExistsById(userId)) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "User Id does not exist, aborting");
		}	
		this.userDao.deleteUser(userId);
	}

	public boolean isUserExistsByName(String userName) throws ApplicationException {

		if  (userName == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null username");
		}
		if  (userName.isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty username");
		}
		if  (userName != (String)userName) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "Username must be a String");
		}

		return this.userDao.isUserExistsByName(userName);
	}

	public boolean isUserExistsById(long userId) throws ApplicationException {

		if (userId <= 0) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "user Id must be positive");
		}
		if (userId != (long)userId){
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "user Id must be an integer number");
		}
		return this.userDao.isUserExistsById(userId);
	}

	public UserType  userClientTypeLogin(String userName, String password) throws ApplicationException {

		if (!userDao.isUserExistsByName(userName)) {
			throw new ApplicationException(ErrorType.NAME_IS_ALREADY_EXISTS, "Username does not exist, aborting");
		}	
		if  (userName == null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null username");
		}
		if  (userName.isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty username");
		}
		if (password==null) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "A null password");
		}
		if  (password.isEmpty()) {
			throw new ApplicationException(ErrorType.GENERAL_ERROR, "An empty password");
		}
		return this.userDao.userClientTypeLogin(userName, password);
	}

	public LoginResponseDataObject login(String userName, String password) {

		return loginResponseDataObject;
	}

	private void validateGetAllUsers() throws ApplicationException {
		List<User> users = userDao.getAllUsers();
		if (users.isEmpty()) {
			throw new ApplicationException(ErrorType.THE_LIST_IS_EMPTY,"The list of users is empty");			
		}
	}
}
