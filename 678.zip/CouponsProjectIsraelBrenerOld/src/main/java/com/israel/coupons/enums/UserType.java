package com.israel.coupons.enums;

public enum UserType {
ADMIN,
CUSTOMER,
COMPANY;



}
