package com.israel.coupons.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.israel.coupons.beans.Purchase;
import com.israel.coupons.beans.User;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;
import com.israel.coupons.utils.JdbcUtils;

@Repository
public class PurchaseDao {

	public PurchaseDao() {
	}

	public long createPurchase(Purchase purchase) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//PurchaseID is defined as a primary key and auto incremented
			String sqlStatement="INSERT INTO purchases (USER_ID, COUPON_ID,  AMOUNT_PURCHASED) VALUES(?,?,?)";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1,purchase.getUserId());
			preparedStatement.setLong(2,purchase.getCouponId());
			preparedStatement.setInt(3,purchase.getAmountPurchased());

			//Executing the update
			preparedStatement.executeUpdate();

			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(!resultSet.next()){
				throw new ApplicationException(ErrorType.GENERAL_ERROR,"Invalid purchase key during creation");
			}
			return resultSet.getLong(1);


		} catch (Exception e) {
			//			e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Create purchase failed (method createPurchase)");
			//			throw new Exception("Failed to create purchase " + purchase.toString(), e);
		} 
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public Purchase getPurchaseById(long purchaseId) throws ApplicationException {
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		Purchase purchase;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM purchases WHERE PURCHASE_ID =?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, purchaseId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return null;
			}
			purchase=extractPurchaseFromResultSet(result);

		} catch (SQLException e) {
			//			throw new Exception("Error in getPurchase(), id = " + purchaseId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get purchase has failed (method getPurchaseById)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return purchase;
	}

	public List<Purchase> getAllPurchases() throws ApplicationException{
		List<Purchase> purchases =  new ArrayList<Purchase>();
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM purchases";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			while (result.next()) {
				purchases.add(extractPurchaseFromResultSet(result));
			}

		} catch (SQLException e) {
			//			throw new Exception("Error in getPurchase(), id = " + purchaseId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get all purchases (method getAllPurchases) has failed");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return purchases;
	}

	public List<Purchase> PurchasesByCouponId(long couponId) throws ApplicationException {
		List<Purchase> purchases = new ArrayList<Purchase>();
		//Turn on the connections
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		try {
			connection = JdbcUtils.getConnection();

			String sqlStatement = "SELECT * FROM purchases where COUPON_ID=?";

			preparedStatement = connection.prepareStatement(sqlStatement);
			preparedStatement.setLong(1, couponId);

			result=preparedStatement.executeQuery();
			while (result.next()) {
				purchases.add(extractPurchaseFromResultSet(result));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new ApplicationException(e,ErrorType.GENERAL_ERROR,"Failed to get All purchases");
		}
		finally {
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return purchases;
	}

	public void updatePurchase(Purchase purchase) throws ApplicationException{

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection = JdbcUtils.getConnection();

			//Creating the SQL query
			//Id is defined as a primary key and auto incremented
			String sqlStatement="UPDATE purchases SET USER_ID = ?, COUPON_ID = ?, AMOUNT_PURCHASED = ? WHERE PURCHASE_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, purchase.getUserId());
			preparedStatement.setLong(2, purchase.getCouponId());
			preparedStatement.setInt(3, purchase.getAmountPurchased());
			preparedStatement.setLong(4, purchase.getPurchaseId());

			//Executing the update
			preparedStatement.executeUpdate();

		} catch (Exception e) {
			//e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" update purchase failed (method updatePurchase)");
			//			throw new Exception("Failed to update purchase " + purchase.toString(), e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void deletePurchase(long purchaseId) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//PurchaseID is defined as a primary key and auto incremented
			String sqlStatement="DELETE FROM purchases where PURCHASE_ID=?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, purchaseId);

			//Executing the update
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			//					e.printStackTrace();
			//			If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" delete purchase failed (method deletePurchase) purchaseId: " + purchaseId);
			//			throw new Exception("Failed to remove purchase " + purchaseId, e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void removeOldCouponPurchases(java.sql.Date todayDate) throws ApplicationException {

		//		long now = Calendar.getInstance().getTimeInMillis();
		//		Date todayDate1 = new Date(now);

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CouponId is defined as a primary key and auto incremented
			String sqlStatement="delete from purchases where COUPON_ID in \r\n" + 
					"(select COUPON_ID from coupons where END_DATE < current_date()); ";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			//			preparedStatement.setLong(1, couponId);

			//Executing the update
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			//					e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			//					throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
			//							+" Create company failed");
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" remove old coupon purchases failed (method removeOldCouponPurchases)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public Long[] checkOldCouponPurchases(java.sql.Date todayDate) throws ApplicationException{

		//		long now = Calendar.getInstance().getTimeInMillis();
		//		Date todayDate1 = new Date(now);

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		Long[] arrResultPurchaseId;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CompanyID is defined as a primary key and auto incremented
			//			String sqlStatement="SELECT COUPON_ID, COMPANY_ID, CATEGORY_ID, TITLE, DESCRIPTION, START_DATE, END_DATE, AMOUNT, PRICE, IMAGE FROM coupons where END_DATE < current_date();";
			String sqlStatement="SELECT p.PURCHASE_ID \r\n" + 
					" FROM coupons c inner join purchases p on c.COUPON_ID = p.COUPON_ID\r\n" + 
					" where c.END_DATE < current_date();\r\n" + 
					"";
			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			//			preparedStatement.setLong(1, couponId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return null;
			}
			arrResultPurchaseId = extractPurchaseIdFromResultSet(result);

		} catch (SQLException e) {
			//			throw new Exception("Error in getCompany(), id = " + couponId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+"check purchases with old coupon has failed (method checkOldCoupons)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return arrResultPurchaseId;
	}

	private Purchase extractPurchaseFromResultSet(ResultSet result) throws SQLException {
		Purchase purchase=new Purchase();
		purchase.setPurchaseId(result.getLong("PURCHASE_ID"));
		purchase.setUserId(result.getLong("USER_ID"));
		purchase.setCouponId(result.getLong("COUPON_ID"));
		purchase.setAmountPurchased(result.getInt("AMOUNT_PURCHASED"));
		return purchase;
	}

	private Long[] extractPurchaseIdFromResultSet(ResultSet result) throws SQLException{

		int size =0;
		if (result != null) 
		{
			result.last();    // moves cursor to the last row
			size = result.getRow(); // get row id 
		}		
		System.out.println("The size of the result  is :" +size +" rows"); //for debugging

		Long[] arrResultPurchaseId = new Long[size];
		Purchase purchase=new Purchase();
		for (int i =0; i < size; i++){
			purchase.setPurchaseId(result.getLong("PURCHASE_ID"));
			arrResultPurchaseId[i] = purchase.getPurchaseId();
			result.absolute(i+1);
		}

		return arrResultPurchaseId;
	}

	public boolean isPurchaseExistsById(long purchaseId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM purchases WHERE PURCHASE_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, purchaseId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if purchase exists by purchase Id (method isPurchaseExistsByPurchaseId");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

	public boolean isPurchaseExistsByUserId(long userId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM purchases WHERE USER_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if purchase exists by user Id (method isPurchaseExistsByUserId");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

	public boolean isPurchaseExistsByCouponId(long couponId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM purchases WHERE COUPON_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, couponId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if purchase exists by coupon Id (method isPurchaseExistsByCouponId");
		}finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}


}