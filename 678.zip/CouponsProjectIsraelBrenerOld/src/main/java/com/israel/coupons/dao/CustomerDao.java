package com.israel.coupons.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import java.sql.SQLException;

import com.israel.coupons.beans.Customer;
import com.israel.coupons.beans.User;
import com.israel.coupons.enums.ErrorType;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.utils.DateUtils;
import com.israel.coupons.utils.JdbcUtils;

@Repository
public class CustomerDao {

	public CustomerDao() {
	}

	public long createCustomer(Customer customer, long userId) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CustomerID is defined as a primary key 
			String sqlStatement="INSERT INTO customers (USER_ID, FIRST_NAME, LAST_NAME) VALUES(?,?,?)";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1,userId);
			preparedStatement.setString(2,customer.getFirstName());
			preparedStatement.setString(3,customer.getLastName());

			//Executing the update
			preparedStatement.executeUpdate();

			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(!resultSet.next()){
				//					throw new ApplicationException(ErrorType.GENERAL_ERROR,"Invalid customer key during creation");
			}
			//						return resultSet.getLong(1);
			return customer.getUserId();


		} catch (Exception e) {
			e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Create customer failed (method createCustomer");
			//			throw new Exception("Failed to create customer " + customer.toString(), e);
		} 
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public Customer getCustomerByCustomerID(long userId) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;
		Customer customer;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM customers WHERE USER_ID =?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return null;
			}
			customer=extractCustomerFromResultSet(result, userId);


		} catch (SQLException e) {
			//			throw new Exception("Error in getCompany(), id = " + userId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get customer by user Id has failed (method getCustomerByCustomerID)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return customer;
	}

	public  List<Customer> getAllCustomers() throws ApplicationException{
		List<Customer> customers =  new ArrayList<Customer>();
		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM customers";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			while (result.next()) {
				customers.add(extractCustomerFromResultSet(result));
			}

		} catch (SQLException e) {
			//			throw new Exception("Error in getCustomer(), id = " + customerId, e);
			//			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Get all customers (method getAllCustomers) has failed");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}
		return customers;
	}

	public void updateCustomer(Customer customer, long userId) throws ApplicationException {

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection = JdbcUtils.getConnection();

			//Creating the SQL query
			//Id is defined as a primary key and auto incremented
			String sqlStatement="UPDATE customers SET FIRST_NAME = ?, LAST_NAME = ? WHERE USER_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement, Statement.RETURN_GENERATED_KEYS);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1, customer.getFirstName());
			preparedStatement.setString(2, customer.getLastName());
			preparedStatement.setLong(3, userId);

			//Executing the update
			preparedStatement.executeUpdate();


		} catch (Exception e) {
			//e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" update customer failed (method updateCustomer)");
			//			throw new Exception("Failed to update customer " + customer.toString(), e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	public void deleteCustomer(long userId) throws ApplicationException{

		//Turn on the connections
		Connection connection=null;
		PreparedStatement preparedStatement=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			//CustomerID is defined as a primary key and auto incremented
			String sqlStatement="DELETE FROM customers where USER_ID=?";

			//Combining between the syntax and our connection
			preparedStatement = connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the update
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			//					e.printStackTrace();
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException(e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" delete customer failed (method deleteCustomer)");
			//			throw new Exception("Failed to remove customer " + userId, e);
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement);
		}
	}

	private Customer extractCustomerFromResultSet(ResultSet result, long userId) throws  SQLException, ApplicationException {
		UserDao userDao = new UserDao();
		User user = userDao.getUserById(userId);
		Customer	 customer=new Customer();

		customer.setUser(user);
		//		customer.setUserId(result.getLong("USER_ID"));
		customer.setFirstName(result.getString("FIRST_NAME"));
		customer.setLastName(result.getString("LAST_NAME"));
		return customer;
	}

	private Customer extractCustomerFromResultSet(ResultSet result) throws  SQLException, ApplicationException {
		UserDao userDao = new UserDao();
		Customer	 customer=new Customer();

		//customer.setUser(user);
		customer.setUserId(result.getLong("USER_ID"));
		User user = userDao.getUserById(customer.getUserId());
		customer.setUser(user);
		customer.setFirstName(result.getString("FIRST_NAME"));
		customer.setLastName(result.getString("LAST_NAME"));
		
		return customer;
	}

	public boolean isCustomerExistsByUserId(long userId) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM customers WHERE USER_ID = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setLong(1, userId);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if customer exists by user id (method isCustomerExistsByUserId)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

	public boolean isCustomerExistsByFirstName(String firstName) throws ApplicationException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet result=null;

		try {
			//Establish a connection from the connection manager
			connection=JdbcUtils.getConnection();

			//Creating the SQL query
			String sqlStatement="SELECT * FROM customers WHERE FIRST_NAME = ?";

			//Combining between the syntax and our connection
			preparedStatement=connection.prepareStatement(sqlStatement);

			//Replacing the question marks in the statement above with the relevant data
			preparedStatement.setString(1, firstName);

			//Executing the query and saving the DB response in the resultSet.
			result=preparedStatement.executeQuery();

			if (!result.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			//If there was an exception in the "try" block above, it is caught here and notifies a level above.
			throw new ApplicationException( e, ErrorType.GENERAL_ERROR, DateUtils.getCurrentDateAndTime()
					+" Failed to check if customer exists by first name(method firstName)");
		}
		finally {
			//Closing the resources
			JdbcUtils.closeResources(connection, preparedStatement, result);	
		}

	}

}


