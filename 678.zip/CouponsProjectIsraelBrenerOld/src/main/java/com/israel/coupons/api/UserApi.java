package com.israel.coupons.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.israel.coupons.beans.User;
import com.israel.coupons.exceptions.ApplicationException;
import com.israel.coupons.logic.UserController;
import com.israel.coupons.data.LoginResponseDataObject;
import com.israel.coupons.data.UserLoginDetailsDataObject;

@RestController
@RequestMapping("/user")
public class UserApi {

	@Autowired
	private UserController userController;

	//method=POST   url=http://localhost:8080/user
	@PostMapping
	public void createUser(@RequestBody User user) throws ApplicationException {
		long id = this.userController.createUser(user);
		System.out.println("The id of the created user is: " + id);
	}

	//method=GET   url=http://localhost:8080/user/444
	@GetMapping("/{userId}")
	public User getUser(@PathVariable("userId") long id) throws ApplicationException {
		System.out.println("user id is: " + id);
		return this.userController.getUserById(id);
	}

	//method=GET   url=http://localhost:8080/user
	@GetMapping
	public List<User> getAllUsers() throws ApplicationException {
		System.out.println("we have to get all users list on webpage");
		return this.userController.getAllUsers();	
	}	

	//method=PUT   url=http://localhost:8080/user
	@PutMapping
	public void updateUser(@RequestBody User user) throws ApplicationException {
		this.userController.updateUser(user);
		System.out.println("updated user is: " + user);
	}

	//Delete user from users (USER_ID is a FK in customers $ purchases)
	//method=DELETE   url=http://localhost:8080/user/444
	@DeleteMapping("/{userId}")
	public void deleteUser(@PathVariable("userId") long id) throws ApplicationException {
		this.userController.deleteUser(id);
		System.out.println("Delete user id: " + id);
	}

	//method=POST   url=http://localhost:8080/user/login
	@PostMapping("/login")
	public LoginResponseDataObject login(@RequestBody UserLoginDetailsDataObject userLoginDetails) {
		System.out.println("userLoginDetails: " + userLoginDetails);  //israel brener added
		return this.userController.login(userLoginDetails.getUserName(), userLoginDetails.getPassword());
	}

	// url = "/user/byAge?age=19
	@GetMapping("/byAge")
	public List<User> getUsersByMinimalAge(@RequestParam("age") int userAge) { //<----   :-)
		System.out.println(userAge);
		return null;
	}

}
